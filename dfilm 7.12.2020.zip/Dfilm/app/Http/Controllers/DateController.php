<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\df_inventories;
use App\df_checkouts;
use DB;

class DateController extends Controller
{
    //

    public function chart(){
  $df_inv = df_checkouts::all();
      $df_dis = DB::select('SELECT dfform,o_projname,o_projdate,o_name,o_companyid,created_at,o_subfile,o_projdura,dfstatus FROM df_checkouts GROUP BY dfform,o_projname,o_projdate,o_name,o_companyid,created_at,o_subfile,o_projdura,dfstatus HAVING COUNT(dfform)>=1;');

      return view('chart.chart',['df_inv' => $df_inv,'df_dis'=>$df_dis]);
    }
    public function editchart($id){
      $df_inv = df_checkouts::all();

      $df_infout = DB::select('select * from df_checkouts where dfform = ?',[$id]);
      foreach ($df_infout as $df_infoout) {

          DB::update('UPDATE df_inventories SET dfstatus = "Available" WHERE dfserial = ?',[$df_infoout->dfserial]);
          DB::update('UPDATE df_checkouts SET dfstatus = "Available" WHERE dfserial = ?',[$df_infoout->dfserial]);
      }


      return redirect('chart/chart');
    }
    public function editpostchart($id){
      $df_infout = DB::select('select * from df_checkouts where dfform = ?',[$id]);
      foreach ($df_infout as $df_infoout) {
        $dfser = request('df'.$df_infoout->dfserial);
        $dfrem = request('dfrem'.$df_infoout->dfserial);
        $user = df_checkouts::where('dfserial', $dfser)->update(['dfremarks' => $dfrem,'dfstatus'=>"Available"]);
        $usera = df_inventories::where('dfserial', $dfser)->update(['dfremarks' => $dfrem,'dfstatus'=>"Available"]);



      }
      return redirect('/df/admin/');
    }



}
