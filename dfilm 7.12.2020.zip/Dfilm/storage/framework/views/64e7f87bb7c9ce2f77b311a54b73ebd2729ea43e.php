<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="generator" content="Mobirise v4.12.4, mobirise.com">
      <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
      <link rel="shortcut icon" href="/img/DubaiFilm_Logo.png" type="image/x-icon">
      <meta name="description" content="">
        <title>Dubai Film Inventory</title>

        <!-- Fonts -->
        <link href="/css/Nunito.css" rel="stylesheet">
        <link rel="preload" as="style" href="/css/main.css">
        <link href="/css/main.css" rel="stylesheet">
        <link href="/css/bootstrap.css" rel="stylesheet">
        <link href="/css/dataTables.bootstrap4.min.css" rel="stylesheet">
        <link href="/css/responsive.bootstrap4.min.css" rel="stylesheet">
        <link href="/css/datemain.css" rel="stylesheet">
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet">
            <script src="/js/jquery-3.5.1.js" charset="utf-8"></script>



  </head>
    <body>
      <div class="links">
    <!-- class="imgposition" -->
<img src="/img/DubaiFilm_Logo.png" alt="" class="imgposition">

          <a type="button" class="btn mj-btn-danger" href="/">Inventory</a>
          <a type="button" class="btn mj-btn-danger" href="/df/user" >Check In Items</a>
          <a type="button" class="btn mj-btn-danger" href="/df/admin">Check Out Items</a>
          <a type="button" class="btn mj-btn-danger" href="/chart/chart"><i class="fa fa-calendar fa-4" aria-hidden="true"></i>Date List</a>
      </div>

            <!-- <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?> -->
            <div class="container-fluid" >

            <?php echo $__env->yieldContent('content'); ?>



        </div>


        <footer>
          © 2020 Dubai Film. All rights reserved.<br/>
          <img src="/img/DubaiFilm_Logo.png" alt="" class="imgpositionfooter">
        </footer>

        <script src="/js/main.js" charset="utf-8"></script>
        <script src="/js/jquery.dataTables.min.js" charset="utf-8"></script>
        <script src="/js/dataTables.bootstrap4.min.js" charset="utf-8"></script>
        <script src="/js/dataTables.responsive.min.js" charset="utf-8"></script>
        <script src="/js/responsive.bootstrap4.min.js" charset="utf-8"></script>
        <script src="/js/bootstrap.min.js" charset="utf-8"></script>
        <script src="/js/datemain.js" charset="utf-8"></script>
        <script>
        $(document).ready(function() {
        $('#example').DataTable();
    } );
        </script>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\Dfilm\resources\views/layouts\layout.blade.php ENDPATH**/ ?>