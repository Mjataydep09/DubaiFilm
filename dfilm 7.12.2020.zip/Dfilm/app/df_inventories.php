<?php

namespace App;
use App\Models\File;
use Illuminate\Database\Eloquent\Model;

class df_inventories extends Model
{
    //
}
