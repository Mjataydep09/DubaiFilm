// function mjtoggleside(){
  $( "#mjtogglesidee" ).click(function() {
    $( "#mjtogglesideee" ).toggleClass( "mj-togglesideshow" );
    $( "#mjbodytoggle" ).toggleClass( "mj-bodytoggle" );
      });


      $( "#mjmodalbtn" ).click(function() {
      $( "#mjmodal" ).toggleClass( "mj-show" );
        });

    $( "#mjmodalhide, #mjmodalcancel, #mjsidetogglehide" ).click(function() {
  $( ".mj-modal-md"  ).removeClass( "mj-show" );
  $( ".mj-toggleside" ).removeClass( "mj-togglesideshow" );
  $( ".mj-body" ).removeClass( "mj-bodytoggle" );
});
$(document).keyup(function(e) {
     if (e.key === "Escape") {
         $( ".mj-modal-md" ).removeClass( "mj-show" );
         $( ".mj-toggleside" ).removeClass( "mj-togglesideshow" );
         $( ".mj-body" ).removeClass( "mj-bodytoggle" );
    }
});
//hide onclick outside the container
$(document).mouseup(function(e)
{
    var modalcontainer = $(".mj-modal-md");
    if (!modalcontainer.is(e.target) && modalcontainer.has(e.target).length === 0)
    {
       $( ".mj-modal-md").removeClass( "mj-show" );
    }
    var sidetogglecont = $(".mj-toggleside");
    if (!sidetogglecont.is(e.target) && sidetogglecont.has(e.target).length === 0)
    {
      $( ".mj-toggleside" ).removeClass( "mj-togglesideshow" );
      $( ".mj-body" ).removeClass( "mj-bodytoggle" );
    }
});

//
//   if(addOrRemove){
//     $("#mjtogglesidee").addClass("mj-togglesideshow");
//   }
// else{
//   $("#mjtogglesidee").removeClass("mj-togglesideshow");
// }
//   if(document.getElementById("mjtogglesidee").className){
//       document.getElementById("mjtogglesidee").className = "mj-togglesideshow";
//   }
//   else{
//       document.getElementById("mjtogglesidee").className = "mj-toggleside";
//   }
// }
// $(document).ready(function(){
// $("#mjtogglesidee").toggleClass('gallery-scale');
// });
