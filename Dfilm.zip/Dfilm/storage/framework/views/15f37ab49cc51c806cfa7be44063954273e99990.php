
<?php $__env->startSection('content'); ?>;

                <div class="title m-b-md">
                  <?php foreach ($showteam as $showt): ?>
                    <p><?php echo e($showt->name); ?> - <?php echo e($showt->age); ?> - <?php echo e($showt->position); ?> - <?php echo e($showt->category); ?></p>
                  <?php endforeach; ?>
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dfilm\resources\views/team/marcc.blade.php ENDPATH**/ ?>