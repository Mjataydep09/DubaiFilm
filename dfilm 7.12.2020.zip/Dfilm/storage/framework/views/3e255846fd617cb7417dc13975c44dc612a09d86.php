


<?php $__env->startSection('content'); ?>
<script>

  document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
      },

      initialDate: '<?php echo e(date('Y-m-d H:i:s')); ?>',
      businessHours: true, // display business hours
      editable: true,
      allDay:true,
      events: [

        <?php foreach ($df_dis as $df_invi): ?>

        {

          title: '<?php echo e($df_invi->dfform); ?>',
          start: '<?php echo e($df_invi->o_projdate); ?>',
          end: '<?php echo e($df_invi->o_projdura); ?>',
          <?php if ($df_invi->dfstatus == 'Unavailable'): ?>
          color: 'red'
          <?php else: ?>
          color: 'green'
          <?php endif; ?>
        },
          <?php endforeach; ?>
      ],
      eventClick: function(info){
        sx = 'mjtogglesideee' + info.event.title;
        document.getElementById(sx).className = 'mj-toggleside mj-togglesideshow';
        document.getElementById('mjbodytoggle').className = 'mj-body mj-border badge-dark mj-bodytoggle';
        info.el.style.borderColor = '#fff';
      }

    });

    calendar.render();

  });

</script>
<div id="mjbodytoggle" class="mj-body mj-border badge-dark">
<div class="container">
  <div class="row mj-margin-top badge-dark">
    <div class="col-md-1">

    </div>
    <div class="col-md-10">
        <div id='calendar'></div>
    </div>
    <div class="col-md-1">

    </div>
  </div>
  </div>


  <p style="margin:3rem">&nbsp;</p>
</div>
  <?php echo $__env->make('layouts\mjmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dfilm\resources\views/chart/chart.blade.php ENDPATH**/ ?>