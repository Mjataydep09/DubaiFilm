<?php $__env->startSection('content'); ?>
<div id="mjbodytoggle" class="mj-body mj-border badge-dark">
<center><img src="/img/DubaiFilm_Logo.svg" alt="" class="imgposition1"></center>
<a id="mjmodalbtn" class="mj-cart" ><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
<a href="/inventory/add_inventory" class="mj-plus" ><i class="fa fa-plus-square" aria-hidden="true"></i></a>
            <h2 style="margin-top:100px;">Dubai Film Inventory List</h2>
                <?php if(session('mssg') === null): ?>
                <?php else: ?>
                <div class="alert alert-dark alert-dismissible fade show" role="alert">
                 <?php echo e(session('mssg')); ?>

                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <?php endif; ?>
<div class="container">

  <table id="example" class="table borderless dt-responsive nowrap" style="width:100%">
        <thead>
            <tr>

                <th data-priority="1">Item</th>
                <th data-priority="1">Serial Number</th>

                <th class="hidden">Status</th>
                <th>Description</th>
                <th>Category</th>
                <th>Remarks</th>
                <th>Storage</th>
                <th>Options</th>
            </tr>
        </thead>
        <tbody>
              <?php foreach ($df_inv as $df_invi): ?>

                  <tr>
                    <?php if ($df_invi->dfstatus === 'Available'): ?>
                      <td class="dtr-controlla"><?php echo e($df_invi->dfitem); ?></td>
                    <?php elseif($df_invi->dfstatus === 'Unavailable'): ?>
                      <td><?php echo e($df_invi->dfitem); ?></td>
                    <?php endif; ?>
                <td><?php echo e($df_invi->dfserial); ?></td>
                <td class="hidden"><?php echo e($df_invi->dfstatus); ?></td>

                <td><?php echo e($df_invi->dfdescription); ?></td>
                <td><?php echo e($df_invi->dfcategory); ?></td>
                <td><?php echo e($df_invi->dfremarks); ?></td>
                <td><?php echo e($df_invi->dfstorage); ?></td>

                <td>
                  <a type="button" href="/inventory/edit_inventory/<?php echo e($df_invi->id); ?>" class="btn btn-outline-success btn-sm" name="button" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                  <button type="button" class="btn btn-outline-warning btn-sm" data-toggle="modal" data-target="#del<?php echo e($df_invi->id); ?>" style="color:yellow;" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i> </button>
                  <?php if($df_invi->dfstatus === 'Unavailable'): ?>
                  <a type="button" href="/add_cart/<?php echo e($df_invi->id); ?>" class="btn btn-outline-danger btn-sm disabled" title="Add to Cart"><i class="fa fa-sign-out" aria-hidden="true"></i> </a>
                  <?php else: ?>
                  <a type="button" href="/add_cart/<?php echo e($df_invi->id); ?>" class="btn btn-outline-secondary btn-sm" title="Add to Cart"><i class="fa fa-sign-out" aria-hidden="true"></i> </a>
                  <?php endif; ?>
                </td>
                    </tr>
              <?php endforeach; ?>
        </tbody>
    </table>

        <?php foreach ($df_inv as $df_invi): ?>
    <div class="modal fade" id="del<?php echo e($df_invi->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel<?php echo e($df_invi->id); ?>" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content" style="color:black;">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel<?php echo e($df_invi->id); ?>">Confirm Delete</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <p> <?php echo e($getid); ?>You are about to delete <b><?php echo e($df_invi->dfitem); ?></b> with Serial Number of <b><?php echo e($df_invi->dfserial); ?></b> record, this procedure is irreversible.</p>
            <p>Do you want to proceed?</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-light" data-dismiss="modal">Close</button>
            <form  method="post">
              <a href="/del/<?php echo e($df_invi->id); ?>" type="button" class="btn btn-danger">Delete</a>
            </form>
          </div>
        </div>
      </div>
    </div>

    <script type="text/javascript">
    $('#del<?php echo e($df_invi->id); ?>').on('shown.bs.modal', function () {
$('#myInput').trigger('focus')
})
    </script>
      <?php endforeach; ?>
      <div id="mjmodal" class="mj-modal-md">
      <div class="mj-border-bottom">
        <a id="mjmodalhide">  <i class="fa fa-times mj-top-right" aria-hidden="true"></i></a>
        <p style="top:0;left:0;position:absolute;background-color:#eee;color:#000;padding: 10px 10px">Job No. DF00<?php echo e($dfcartcount); ?></p>
        <h1 style="font-size:2rem">Equipment Checkout Form</h1>
      </div>
      <div class="container tablecart">
        <table class="table borderless">
          <tr>
            <th>Serial Number</th>
            <th>Equipment</th>
            <th>Storage</th>

            <th></th>
          </tr>
        <form class="" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php foreach ($dfinvcart as $dfinvicart): ?>
                <tr>
                  <td><?php echo e($dfinvicart->dfserial); ?></td>
                  <td><?php echo e($dfinvicart->dfitem); ?></td>
                  <td><?php echo e($dfinvicart->dfstorage); ?></td>
                <!-- name="dfstatusyy<?php echo e($dfinvicart->id); ?>"-->
                  <td><a type="button" class="btn btn-warning btn-sm" style="color:#fff" href="/remove_cart/<?php echo e($dfinvicart->id); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a></td>
                </tr>
            <?php endforeach; ?>
              </table>
          <div class="container">
              <h3>Recipient Details<h3>
                <div class="form-inline">
                  <label for="" class="form-label mj-half">Upload Sub Item: </label>
                  <input style="height:auto;" class="form-control mj-half form-width" type="file" name="o_subfile[]" value="" multiple/>
                </div>
                <div class="form-inline">
                  <label for="" class="form-label mj-half">Sub Item list: </label>
                  <input class="form-control mj-half form-width" type="text" name="o_subf" value=""/>
                </div>
              <div class="form-inline">
                <label for="" class="form-label mj-half">Name: </label>
                <input class="form-control mj-half form-width" type="text" name="o_name" value="">
              </div>
              <div class="form-inline">
                <label for="" class="form-label mj-half">Company ID: </label>
                <input class="form-control mj-half form-width" type="text" name="o_companyid" value="">
              </div>
              <div class="form-inline">
                <label for="" class="form-label mj-half">Project Name: </label>
                <input class="form-control mj-half form-width" type="text" name="o_projname" value="">
              </div>
              <div class="form-inline">
                <label for="" class="form-label mj-half">Project Date Start: </label>
                <input class="form-control mj-half form-width" type="date" name="o_projdate" value="">
              </div>
              <div class="form-inline">
                <label for="" class="form-label mj-half">Project Date End: </label>
                <input class="form-control mj-half form-width" type="date" name="o_projdura" value="">
              </div>
            </div>
      </div>
      <div class="mj-border-top">
        <div class="form-group" style="margin:3%">
          <input type="submit" class="btn mj-btn-danger btn-sm form-control" value="Check-out">
          <a type="button" class="btn mj-btn-danger btn-sm form-control" id="mjmodalcancel">Close</a>
        </div>
      </div>
      </form>
      </div>
</div>
                  <p style="margin:3rem">&nbsp;</p>
                  <p><?php echo e($getid); ?></p>
                  <p><?php echo e($getname); ?></p>
                  <!-- http://127.0.0.1:8000/?ProductID=0123&PName=Computerkemekeme -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dfilm\resources\views/welcome.blade.php ENDPATH**/ ?>