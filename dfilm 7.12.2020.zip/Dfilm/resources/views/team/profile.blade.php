@extends('layouts\layout')
@section('content');

                <div class="title m-b-md">
                    <p>{{ $showteam->name }} - {{ $showteam->age }} - {{ $showteam->position }} - {{ $showteam->category }}</p>
                </div>

@endsection
