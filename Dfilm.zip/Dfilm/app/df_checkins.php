<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class df_checkins extends Model
{
    //
}
