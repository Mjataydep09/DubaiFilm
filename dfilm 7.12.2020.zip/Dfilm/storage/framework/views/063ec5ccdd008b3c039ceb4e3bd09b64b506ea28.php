
<?php $__env->startSection('content'); ?>;

                <div class="title m-b-md">
                    <p><?php echo e($showteam->name); ?> - <?php echo e($showteam->age); ?> - <?php echo e($showteam->position); ?> - <?php echo e($showteam->category); ?></p>
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dfilm\resources\views/team/profile.blade.php ENDPATH**/ ?>