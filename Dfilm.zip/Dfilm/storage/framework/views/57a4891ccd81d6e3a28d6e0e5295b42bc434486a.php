<?php $__env->startSection('content'); ?>

                <div class="title m-b-md">
                CHECK IN ITEMS
                </div>
                <?php foreach ($showteam as $showt): ?>
                  <p><?php echo e($showt->name); ?> - <?php echo e($showt->age); ?> - <?php echo e($showt->position); ?> - <?php echo e($showt->category); ?></p>
                <?php endforeach; ?>
                <p><?php echo e(session('mssg')); ?></p>
                <div class="container" style="color:#fff !important;">
              <table id="example" class="table table-striped table-bordered dt-responsive" style="width:100%">
                    <thead>
                        <tr>
                            <th>Form ID</th>
                              <th>Project</th>
                              <th>Project Date</th>
                              <th>Project Until</th>
                              <th>Recipient</th>
                              <th  class="hidden">Company ID</th>
                              <th class="hidden">Equipment</th>


                              <th>Records List</th>
                        </tr>
                    </thead>
                    <tbody>

                      <?php foreach ($df_dis as $df_invi): ?>

                        <?php
                        $df_item = DB::select('select * from df_checkins where dfstatus = "Available" AND dfform = ?',[$df_invi->dfform]);
                        ?>
                          <tr>
                            <td><?php echo e($df_invi->dfform); ?></td>
                            <td ><?php echo e($df_invi->o_projname); ?></td>
                            <td><?php echo e($df_invi->o_projdate); ?></td>
                            <td><?php echo e($df_invi->o_projdura); ?></td>
                            <td><?php echo e($df_invi->o_name); ?></td>
                            <td  class="hidden"><?php echo e($df_invi->o_companyid); ?></td>
                            <td class="hidden">  <?php foreach ($df_item as $df_items): ?><?php echo e($df_items->dfserial); ?> -  <?php echo e($df_items->dfitem); ?> - <?php echo e($df_items->dfremarks); ?><?php endforeach; ?></td>
                      
                            <td>
                              <a type="button" class="form-control btn btn-info btn-sm"  onclick="tog<?php echo e($df_invi->dfform); ?>()"  title="Equipments"><i class="fa fa-picture-o" aria-hidden="true"></i></a>
                            </td>
                          </tr>

                                <script type="text/javascript">
                                function tog<?php echo e($df_invi->dfform); ?>(){
                                  <?php $mjtogg = 'Available'; ?>
                                  document.getElementById('mjtogglesideee<?php echo e($df_invi->dfform); ?>').className = 'mj-toggleside mj-togglesideshow';
                                  document.getElementById('mjbodytoggle').className = 'mj-body mj-border badge-dark mj-bodytoggle';
                                }
                                </script>


                        <?php endforeach; ?>


                    </tbody>
                </table>


              </div>
                <a href="/df/moderator"> --> New team member.</a>
                <p></p>
<?php echo $__env->make('layouts\mjmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dfilm\resources\views/category/homeuser.blade.php ENDPATH**/ ?>