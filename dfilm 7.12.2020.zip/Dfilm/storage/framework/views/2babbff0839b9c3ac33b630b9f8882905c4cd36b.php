<?php $__env->startSection('content'); ?>;

                <div class="title m-b-md">
                  Home Admin
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dfilm\resources\views/category\homeadmin.blade.php ENDPATH**/ ?>