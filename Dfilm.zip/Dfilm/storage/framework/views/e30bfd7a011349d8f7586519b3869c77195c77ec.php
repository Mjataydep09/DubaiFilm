<?php $__env->startSection('content'); ?>
<div id="mjbodytoggle" class="mj-body mj-border badge-dark">
                <div class="title m-b-md">
                CHECK OUT ITEMS

                </div>


                  <div class="container">
                <table id="example" class="table table-striped table-bordered dt-responsive" style="width:100%">
                      <thead>
                          <tr>
                              <th>Form ID</th>
                                <th>Project</th>
                                <th>Project Date</th>
                                <th>Project Until</th>
                                <th>Recipient</th>
                                <th  class="hidden">Company ID</th>
                                <th class="hidden">Checkout</th>
                                <th class="hidden">Equipment</th>


                                <th>Actions</th>
                          </tr>
                      </thead>
                      <tbody>

                        <?php foreach ($df_dis as $df_invi): ?>

                        
                          <?php
                          $df_item = DB::select('select * from df_checkouts where dfstatus = "Unavailable" AND dfform = ?',[$df_invi->dfform]);
                          ?>
                            <tr>
                              <td><?php echo e($df_invi->dfform); ?></td>
                              <td ><?php echo e($df_invi->o_projname); ?></td>
                              <td><?php echo e($df_invi->o_projdate); ?></td>
                              <td><?php echo e($df_invi->o_projdura); ?></td>
                              <td><?php echo e($df_invi->o_name); ?></td>
                              <td  class="hidden"><?php echo e($df_invi->o_companyid); ?></td>
                              <td class="hidden">  <?php foreach ($df_item as $df_items): ?><?php echo e($df_items->dfserial); ?> -  <?php echo e($df_items->dfitem); ?><?php endforeach; ?></td>
                              <td  class="hidden"><?php echo e($df_invi->created_at); ?></td>
                              <td>
                                <a type="button" class="form-control btn btn-info btn-sm"  onclick="tog<?php echo e($df_invi->dfform); ?>()"  title="Equipments"><i class="fa fa-picture-o" aria-hidden="true"></i></a>
                              </td>
                            </tr>

                                  <script type="text/javascript">
                                  function tog<?php echo e($df_invi->dfform); ?>(){
                                    <?php $mjtogg = 'Unavailable'; ?>
                                    document.getElementById('mjtogglesideee<?php echo e($df_invi->dfform); ?>').className = 'mj-toggleside mj-togglesideshow';
                                    document.getElementById('mjbodytoggle').className = 'mj-body mj-border badge-dark mj-bodytoggle';
                                  }
                                  </script>


                          <?php endforeach; ?>


                      </tbody>
                  </table>


                </div>
  <p style="margin:3rem">&nbsp;</p>
              </div>
<?php echo $__env->make('layouts\mjmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts\layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Dfilm\resources\views/category/homeadmin.blade.php ENDPATH**/ ?>