@extends('layouts\layout')
@section('content')

                <div class="title m-b-md">
                  Add Items here

                </div>
                  <p>{{session('mssg')}}</p>
                <form class="form-group" method="post">
                  @csrf
                    <div class="form-inline">
                      <label for="dfserial" class="form-label">&nbsp;Serial Number:&nbsp;</label>
                      <input type="text" class="form-control" name="dfserial" id="dfserial">
                      <label for="dfstatus" class="form-label">&nbsp;Quantity: &nbsp;</label>
                      <input type="text" class="form-control" value="Available" name="dfstatus" id="dfstatus">
                    </div><br/>
                    <div class="form-group">
                      <label for="dfitem" class="form-label">&nbsp;Item: &nbsp;</label>
                      <input type="text" class="form-control" name="dfitem" id="dfitem">
                      <label for="dfcategory" class="form-label">&nbsp;Category: &nbsp;</label>
                      <select class="form-control" name="dfcategory">
                        <option value="DSLR">DSLR</option>
                        <option value="Action Camera">Action Camera</option>
                        <option value="Accessories">Accessories</option>
                      </select>
                      </div>
                      <div class="form-inline">
                      <label class="form-label">&nbsp;Item Storage: &nbsp;</label>
                      <select class="form-control" name="dfstorage1">
                        <option value="Grey Box">Grey Box</option>
                        <option value="Black Racks">Black Racks</option>
                        <option value="Grey Racks">Grey Racks</option>
                        <option value="Blue Containers">Blue Containers</option>
                        <option value="Red Containers">Red Containers</option>
                      </select>
                      <select class="form-control" name="dfstorage2">
                        <option value="red">red</option>
                        <option value="yellow">yellow</option>
                        <option value="blue">blue</option>
                        <option value="white">white</option>
                        <option value="green">green</option>
                      </select>
                      <select class="form-control" name="dfstorage3">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="dfdescription" class="form-label">Description: </label>
                      <input type="text" class="form-control" name="dfdescription" id="dfdescription">
                    </div>
                  <input type="submit" class="btn btn-sm btn-danger" name="dfsubmit" value="Submit">
                  <a href="/" class="btn btn-sm btn-danger">Back</a>

                </form>


@endsection
